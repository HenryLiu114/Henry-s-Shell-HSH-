@echo off
del *.class